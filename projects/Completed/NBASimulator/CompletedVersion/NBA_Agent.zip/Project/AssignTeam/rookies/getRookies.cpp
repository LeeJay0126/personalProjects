#include <iostream>
using namespace std;
#include "Rookies.h"
#include "RookiesUtil.h"
#include <string>
#include <fstream>
#include <iomanip>

void readData(string names[], string fileName);


int main(){
    
    RookiesUtil util;
    
    srand (time(nullptr));
    int rookieCount = 0;
    Rookies rookieClass[60];
    
    util.recursion(500, 2020, rookieCount, rookieClass);
    
    

    
    
}

