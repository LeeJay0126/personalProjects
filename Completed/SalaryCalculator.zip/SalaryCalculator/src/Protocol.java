public interface Protocol {
    int PORT = 18888;
    int HOURS = 1;
    int WAGES = 2;
    int INITSALARY = 3;
    int RESULT = 4;
    int DONE = -1;
}
